This backend uses the standard "mysql" command line program.
